package test;

import battlecode.common.*;

public class Building extends Global {
	private static Direction forward;
	private static Direction[] prefdir;
	private static Direction[] possibledir=new Direction[8];
	private static Direction[] alldir=new Direction[8];
	
	private static void initdir() throws GameActionException {
		for(int des=0;des<Direction.allDirections().length-1;des++) {alldir[des]=Direction.allDirections()[des];
		}	
		int pos=0;
		for(MapLocation dir:Nav.getpossiblSenseeadj(rc.getLocation())) {
			
			Direction frwrd=rc.getLocation().directionTo(dir);
			Direction[] checkd= new Direction[] {frwrd,frwrd.rotateRight(),frwrd.rotateLeft()};
			for(Direction tes:checkd) {
				MapLocation trget=dir.add(tes);
				if(!rc.senseFlooding(trget) && Math.abs(rc.senseElevation(trget)-rc.senseElevation(dir))<4) {
					possibledir[pos]=rc.getLocation().directionTo(dir);
					pos++;
					break;
				}
			}
		}
		for(RobotInfo ri:rc.senseNearbyRobots()) {
			if(ri.getType()==RobotType.HQ) {
				forward=rc.getLocation().directionTo(ri.getLocation());
				break;
			}
		}
	}
}
