package test;

import java.util.LinkedList;

import battlecode.common.*;

public class Pathfind extends Global{
	public static boolean foundborder=false;
	public static boolean going(MapLocation goal) throws GameActionException {

		
		
		
		
	//	System.out.println("going to "+goal);
		int nbrpas=0;
		myloc=rc.getLocation();
		int maxpas=(int)Math.sqrt(myloc.distanceSquaredTo(goal));
		maxpas=Math.max(maxpas*3,20);		
		boolean moved=false;
		 
		
		
		Direction prevdir=Direction.CENTER;
		while(!rc.getLocation().isAdjacentTo(goal)) {
		myloc=rc.getLocation();
		Direction forward=dirto(goal);


		while(!rc.isReady()) {}
		if(!forward.equals(prevdir) && rc.canMove(forward) && !rc.senseFlooding(myloc.translate(forward.getDeltaX(),forward.getDeltaY()))) {
			moved=true;
			rc.move(forward);
			nbrpas++;
			prevdir=Direction.CENTER;
			
			Clock.yield();
		
		}
		else {
			while(!moved && !foundborder ) {
				forward=forward.rotateLeft();
				if(rc.canMove(forward) && !rc.senseFlooding(myloc.translate(forward.getDeltaX(),forward.getDeltaY())) && !prevdir.equals(forward)) {

					moved=true;
					rc.move(forward);
					nbrpas++;
					prevdir=forward.opposite();

					
					Clock.yield();
					break;
				}else 	if(!rc.onTheMap(myloc.translate(forward.getDeltaX(),forward.getDeltaY()))) {
				foundborder=true;
			}
			}
		//	if(prevdir.equals(forward)) {prevdir=Direction.CENTER; foundborder=!foundborder;}
			while(!moved && foundborder ) {
				forward=forward.rotateRight();
				if(rc.canMove(forward) && !rc.senseFlooding(myloc.translate(forward.getDeltaX(),forward.getDeltaY()))) {
					moved=true;
					rc.move(forward);
					nbrpas++;
					prevdir=forward.opposite();
					
					Clock.yield();
					break;
				}else 	if(!rc.onTheMap(myloc.translate(forward.getDeltaX(),forward.getDeltaY()))) {
				foundborder=false;
			}
			}
			
			moved=false;
			
			
		}	if(nbrpas>maxpas) {
			myloc=rc.getLocation();
			return false;
		}
		}
		foundborder=false;
		myloc=rc.getLocation();
		return true;
	}
	static Direction dirto(MapLocation goal) {
		myloc=rc.getLocation();
		Direction nor=myloc.directionTo(goal);
		if(nor.getDeltaX()*nor.getDeltaY()!=0) {
			return nor;
		}
		if(myloc.x==goal.x ||myloc.y==goal.y) {
			return nor;
		}
		if(myloc.x>goal.x) {
			if(myloc.y>goal.y) {
				nor=Direction.SOUTHWEST;
			}
			else {nor=Direction.NORTHWEST;
		}
			}else {
				if(myloc.y>goal.y) {
					nor=Direction.SOUTHEAST;
				}
				else {nor=Direction.NORTHEAST;
			}
		}
		return nor;
	}
	
	public static boolean dronepath(MapLocation goal) throws GameActionException {
		Direction forwarddir=rc.getLocation().directionTo(goal);
		Direction[] checkdir=new Direction[] {forwarddir,forwarddir.rotateLeft(),forwarddir.rotateRight(),forwarddir.rotateLeft().rotateLeft(),forwarddir.rotateRight().rotateRight()};;
		int max =(int)Math.sqrt(rc.getLocation().distanceSquaredTo(goal));
		max=max+15;
		int pas=0;
		System.out.println("max "+max);
		System.out.println("goal "+goal);
		while(!rc.getLocation().equals(goal) && pas<max) {
			if(rc.canSenseLocation(goal)) {
				if(rc.senseRobotAtLocation(goal)!=null) {
			if(rc.senseRobotAtLocation(goal).getType()==RobotType.DELIVERY_DRONE) {
				return false;
			}}}
			forwarddir=rc.getLocation().directionTo(goal);
			while(!rc.isReady()) {Clock.yield();}
		while(true) {
			if(rc.canMove(forwarddir)) {
				rc.move(forwarddir);
				pas++;
				break;
			}forwarddir=forwarddir.rotateLeft();
		}
		}
		if(rc.getLocation().equals(goal)) {return true;}
		return false;
	}
	
public static boolean doneHQ(MapLocation goal) throws GameActionException {
	int nbrpas=0;
	myloc=rc.getLocation();
	int maxpas=(int)Math.sqrt(myloc.distanceSquaredTo(goal));
	maxpas=maxpas+30;		
	boolean moved=false;
	boolean foundborder=false;
	
	
	Direction prevdir=Direction.CENTER;
	while(rc.getLocation().distanceSquaredTo(goal)>25) {
		if(rc.canSenseLocation(goal)) {
			if(rc.senseRobotAtLocation(goal)!=null) {
		if(rc.senseRobotAtLocation(goal).getType()==RobotType.DELIVERY_DRONE) {
			return false;
		}}}
		
	myloc=rc.getLocation();
	Direction forward=dirto(goal);


	while(!rc.isReady()) {}
	if(!forward.equals(prevdir) && rc.canMove(forward) ) {
		moved=true;
		rc.move(forward);
		nbrpas++;
	//	prevdir=forward.opposite();
		prevdir=Direction.CENTER;
		
		Clock.yield();
	
	}
	else {
		while(!moved && !foundborder ) {
			forward=forward.rotateLeft();
			if(rc.canMove(forward) && !prevdir.equals(forward)) {

				moved=true;
				rc.move(forward);
				nbrpas++;
				prevdir=forward.opposite();

				
				Clock.yield();
				break;
			}else 	if(!rc.onTheMap(myloc.translate(forward.getDeltaX(),forward.getDeltaY()))) {
			foundborder=true;
		}
		}
		while(!moved && foundborder ) {
			forward=forward.rotateRight();
			if(rc.canMove(forward)) {
				moved=true;
				rc.move(forward);
				nbrpas++;
				prevdir=forward.opposite();
				
				Clock.yield();
				break;
			}else 	if(!rc.onTheMap(myloc.translate(forward.getDeltaX(),forward.getDeltaY()))) {
			foundborder=false;
		}
		}
		
		moved=false;
		
		
	}	if(nbrpas>maxpas) {
		return false;
	}
	}
	return true;
}
}

