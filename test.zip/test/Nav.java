package test;

import java.util.ArrayList;

import battlecode.common.*;

public class Nav extends Global {
	
	private static ArrayList<MapLocation> visited=new ArrayList<MapLocation>();
	private static ArrayList<MapLocation> visited1=new ArrayList<MapLocation>();
	private static Direction forwarddir=Direction.NORTHEAST;
	private static Direction[] checkdir=new Direction[] {forwarddir,forwarddir.rotateLeft(),forwarddir.rotateRight(),forwarddir.rotateLeft().rotateLeft(),forwarddir.rotateRight().rotateRight()};;
	

	private static int maxdist;
	private static int memdir=0;
	private static int autochng=0;
	private static int failnbr=0;

	public static void first() throws GameActionException {
		myloc=rc.getLocation();
		radius=racine[squaredradius];		
		updateRobot(rc.senseNearbyRobots());
		System.out.println("mining");
		Soupbaby.getsoup();
		//Miner.getsoup();
		//Miner.firstmove();				
	}

	public static MapLocation[] getadj(MapLocation s){
		MapLocation[] child=new MapLocation[8];
		int i=0;
		for(Direction dir:Direction.allDirections()) {
		
		if(dir==Direction.CENTER) {continue;}
		if(rc.onTheMap(new MapLocation(s.x+dir.getDeltaX(),s.y+dir.getDeltaY()))) {
				child[i]=new MapLocation(s.x+dir.getDeltaX(),s.y+dir.getDeltaY());
		i++;}
		}
		
		
		return child;
	}
	

	public static ArrayList<MapLocation> getvisionLimit(){
		ArrayList<MapLocation> limits=new ArrayList<MapLocation>();
		myloc=rc.getLocation();
		squaredradius=rc.getCurrentSensorRadiusSquared();
		radius=racine[squaredradius];
		int right=Math.min(radius,width-myloc.x-1);
		int top =Math.min(radius,height-myloc.y-1);
		int buttom=Math.min(radius,myloc.y-1);
		int left=Math.min(radius,myloc.x-1);			
	int i=-left+1;	
		while(i<right) {								
				limits.add(new MapLocation(myloc.x+i,myloc.y+Math.min(top,racine[squaredradius-carre[Math.abs(i)]])));
				limits.add(new MapLocation(myloc.x+i,myloc.y-Math.min(buttom,racine[squaredradius-carre[Math.abs(i)]])));		
		i++;
		}

		int j=1;
		while(carre[j]<=squaredradius-carre[left]) {
			
	limits.add(new MapLocation(myloc.x-left,myloc.y+Math.min(top,j)));
	limits.add(new MapLocation(myloc.x-left,myloc.y-Math.min(buttom,j)));				
		j++;			
		}
		
		
		 j=1;
		while(carre[j]<=squaredradius-carre[right] ) {
			limits.add(new MapLocation(myloc.x+right,myloc.y+Math.min(top,j)));
			limits.add(new MapLocation(myloc.x+right,myloc.y-Math.min(buttom,j)));

		j++;
			
		}
		limits.add(new MapLocation(myloc.x+right,myloc.y));
		limits.add(new MapLocation(myloc.x-left,myloc.y));
		
		return limits;
	}
	public static ArrayList<MapLocation> getSenseadjacent(MapLocation s){
		ArrayList<MapLocation> adj=new ArrayList<MapLocation>();
		if(rc.canSenseLocation(new MapLocation(s.x-1,s.y+1))) {
			adj.add(new MapLocation(s.x-1,s.y+1));
		}
		if(rc.canSenseLocation(new MapLocation(s.x,s.y+1))) {
			adj.add(new MapLocation(s.x,s.y+1));
		}
		if(rc.canSenseLocation(new MapLocation(s.x+1,s.y+1))) {
			adj.add(new MapLocation(s.x+1,s.y+1));
		}
		
		if(rc.canSenseLocation(new MapLocation(s.x-1,s.y))) {
			adj.add(new MapLocation(s.x-1,s.y));
		}
		
		if(rc.canSenseLocation(new MapLocation(s.x+1,s.y))) {
			adj.add(new MapLocation(s.x+1,s.y));
		}
		
		if(rc.canSenseLocation(new MapLocation(s.x-1,s.y-1))) {
			adj.add(new MapLocation(s.x-1,s.y-1));
		}
		if(rc.canSenseLocation(new MapLocation(s.x,s.y-1))) {
			adj.add(new MapLocation(s.x,s.y-1));
		}
		if(rc.canSenseLocation(new MapLocation(s.x+1,s.y-1))) {
			adj.add(new MapLocation(s.x+1,s.y-1));
		}
		
		return adj;
	}
	public static ArrayList<MapLocation> getpossiblSenseeadj(MapLocation s) throws GameActionException{
		ArrayList<MapLocation> adj=new ArrayList<MapLocation>();
		if(rc.canSenseLocation(s)) {
		if(rc.canSenseLocation(new MapLocation(s.x-1,s.y+1))) {
			
			if(Math.abs(rc.senseElevation((new MapLocation(s.x-1,s.y+1)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x-1,s.y+1)) ) {
				adj.add(new MapLocation(s.x-1,s.y+1));
			}	
		}
		if(rc.canSenseLocation(new MapLocation(s.x,s.y+1))) {
			if(Math.abs(rc.senseElevation((new MapLocation(s.x,s.y+1)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x,s.y+1))) {
			adj.add(new MapLocation(s.x,s.y+1));}
		}
		if(rc.canSenseLocation(new MapLocation(s.x+1,s.y+1))) {
			if(Math.abs(rc.senseElevation((new MapLocation(s.x+1,s.y+1)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x+1,s.y+1))) {
			adj.add(new MapLocation(s.x+1,s.y+1));}
		}
		
		if(rc.canSenseLocation(new MapLocation(s.x-1,s.y))) {
			if(Math.abs(rc.senseElevation((new MapLocation(s.x-1,s.y)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x-1,s.y)) ) {
			adj.add(new MapLocation(s.x-1,s.y));}
		}
		
		if(rc.canSenseLocation(new MapLocation(s.x+1,s.y))) {
			if(Math.abs(rc.senseElevation((new MapLocation(s.x+1,s.y)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x+1,s.y))) {
			adj.add(new MapLocation(s.x+1,s.y));}
		}
		
		if(rc.canSenseLocation(new MapLocation(s.x-1,s.y-1))) {
			if(Math.abs(rc.senseElevation((new MapLocation(s.x-1,s.y-1)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x-1,s.y-1))) {
			adj.add(new MapLocation(s.x-1,s.y-1));}
		}
		if(rc.canSenseLocation(new MapLocation(s.x,s.y-1))) {
			if(Math.abs(rc.senseElevation((new MapLocation(s.x,s.y-1)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x,s.y-1))) {
			adj.add(new MapLocation(s.x,s.y-1));}
		}
		if(rc.canSenseLocation(new MapLocation(s.x+1,s.y-1))) {
			if(Math.abs(rc.senseElevation((new MapLocation(s.x+1,s.y-1)))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x+1,s.y-1))) {
			adj.add(new MapLocation(s.x+1,s.y-1));}
		}
		}
		
		return adj;
	}

	public static void  updateRobot(RobotInfo[] nearby) {
		for(RobotInfo rb:nearby) {
			 switch (rb.getType()) {
             case HQ:                 if(rc.getTeam()==rb.getTeam()) {myHQ=rb.getLocation();mybuild.put(rb.getLocation(),RobotType.HQ);
             }else {opHQ=rb.getLocation();
             //doSYME()
             }
            	 break;
            
             case REFINERY:                     break;
             case VAPORATOR:                  break;
             case DESIGN_SCHOOL:            break;
             case FULFILLMENT_CENTER:  break;
             case LANDSCAPER:                 break;
             case DELIVERY_DRONE:          break;
             case NET_GUN:                       break;
             case MINER:                           break;
         }
		}
	}
	public RobotInfo closest(RobotInfo[] nearby) {
		if(nearby.length==0) {return null;}
		RobotInfo mindis=nearby[0];
		for(int i=1;i<nearby.length;i++) {
			if(myloc.distanceSquaredTo(mindis.getLocation())>myloc.distanceSquaredTo(nearby[i].getLocation())) {
				mindis=nearby[i];
			}
		}
		return mindis;
	}
	public static ArrayList<MapLocation> getvision(){
		ArrayList<MapLocation> vision=new ArrayList<MapLocation>();
		myloc=rc.getLocation();
		squaredradius=rc.getCurrentSensorRadiusSquared();
		radius=racine[squaredradius];
		int right=Math.min(radius,width-myloc.x-1);
		int top =Math.min(radius,height-myloc.y-1);
		int buttom=Math.min(radius,myloc.y-1);
		int left=Math.min(radius,myloc.x-1);	
		int i=1,j=1;
		 while(carre[i]<=carre[right]) {
			   j=1;
			   while(carre[j] <=squaredradius-carre[i]) {
				   vision.add(new MapLocation(myloc.x+i,myloc.y+j));
				   j++;
			   }
			
			   i++;
		   }

		 if(left==right && top==buttom) {
			 for(MapLocation e:doXsyme(doYsyme(vision))){
				 vision.add(e);
			 }
		 }else  {
			  i=1;j=1;
			 while(carre[i]<=carre[right]) {
				   j=1;
				   while(carre[j] <=squaredradius-carre[i] &&j<=buttom) {
					   vision.add(new MapLocation(myloc.x+i,myloc.y-j));
					   j++;
				   }i++;
			   }
			 
			 i=1;j=1;
			 while(carre[i]<=carre[left]) {
				   j=1;
				   while(carre[j] <=squaredradius-carre[i] &&j<=top) {
					   vision.add(new MapLocation(myloc.x-i,myloc.y+j));
					   j++;
				   }i++;
			   }
			 
			 i=1;j=1;
			 while(carre[i]<=carre[left]) {
				   j=1;
				   while(carre[j] <=squaredradius-carre[i] &&j<=buttom) {
					   vision.add(new MapLocation(myloc.x-i,myloc.y-j));
					   j++;
				   }i++;
			   }
			 
		 }
		 for(int k=-left;k<=right;k++) {
			 vision.add(new MapLocation(myloc.x+k,myloc.y));
		 }
		 for(int k=-buttom;k<=top;k++) {
			 vision.add(new MapLocation(myloc.x,myloc.y+k));
		 }
		
		return vision;
	}
	
	private static ArrayList<MapLocation> doXsyme(ArrayList<MapLocation> ini){
		ArrayList<MapLocation> sym=new ArrayList<MapLocation>();
		for(MapLocation node :ini) {
			sym.add(node);
			sym.add(new MapLocation(2*myloc.x-node.x,node.y));
		}
		return sym;
	}
	private static ArrayList<MapLocation> doYsyme(ArrayList<MapLocation> ini){
		ArrayList<MapLocation> sym=new ArrayList<MapLocation>();
		for(MapLocation node :ini) {
			sym.add(node);
			sym.add(new MapLocation(node.x,2*myloc.y-node.y));
		}
		return sym;
	}
	
	public static ArrayList<MapLocation> explore() throws GameActionException {
		
		maxdist=carre[Math.min(Math.min(radius,width-myloc.x-1),height-myloc.y-1)];
		
		squaredradius=rc.getCurrentSensorRadiusSquared();
		radius=racine[squaredradius];
		myloc=rc.getLocation();
		maxdist=carre[Math.min(Math.min(radius,width-myloc.x-1),height-myloc.y-1)];
		if(!rc.canSenseLocation(myloc.translate(3*forwarddir.getDeltaX(), 3*forwarddir.getDeltaY())) ) {
			changecheckdir();
			memdir --;
		
		}
		trypath=decidemovement(myloc);
		trypath.remove(0);
		while(trypath.size()==0) {
			changecheckdir();
		
			trypath=decidemovement(myloc);
			visited1.clear();
			trypath.remove(0);
			
		}
		if(myloc.directionTo(trypath.get(trypath.size()-1))!=forwarddir) {
			memdir++;
		}
		autochng++;
		if(autochng>6) {
			changecheckdir();
			autochng=0;
		}
		return trypath;
		}
		
		
		
	
	
	
	public static ArrayList<MapLocation> decidemovement(MapLocation i) throws GameActionException {
		ArrayList<MapLocation> childrens=getchildforward(i);
		ArrayList<MapLocation> maxi=new ArrayList<MapLocation>();
		ArrayList<MapLocation> holder;
		maxi.add(i);
		if(myloc.distanceSquaredTo(i)>=Math.max(maxdist,1) || childrens.size()==0) {
			
			return maxi;
		}
		for(MapLocation file:childrens) {
			if(!visited1.contains(file)) {
			visited1.add(file);
			holder=decidemovement(file);
			if(myloc.distanceSquaredTo(holder.get(holder.size()-1))>=Math.max(maxdist,1) && !visited.contains(holder.get(holder.size()-1))) {
				maxi=holder;
				maxi.add(0,i);
				 return maxi;
			}
			if(myloc.distanceSquaredTo(holder.get(holder.size()-1))>myloc.distanceSquaredTo(i)) {
				maxi=holder;
				maxi.add(0,i);
			}}
		}
		return  maxi;
	}
	
	private static ArrayList<MapLocation> getchildforward(MapLocation s) throws GameActionException{
		ArrayList<MapLocation> child=new ArrayList<MapLocation>();
		for(Direction dir:checkdir) {
		
		if(rc.canSenseLocation(s.translate(dir.getDeltaX(),dir.getDeltaY()))) {
			
			
			if(Math.abs(rc.senseElevation(new MapLocation(s.x+dir.getDeltaX(),s.y+dir.getDeltaY()))-rc.senseElevation(s))<4 && !rc.senseFlooding(new MapLocation(s.x+dir.getDeltaX(),s.y+dir.getDeltaY())) ) {
				child.add(new MapLocation(s.x+dir.getDeltaX(),s.y+dir.getDeltaY()));
			}	
		}
		}
		
		
		return child;
	}
	public static void changecheckdir() {
		if(memdir>=16) {memdir=0;}
		if(memdir<9) {memdir++;
		System.out.println("if");
		forwarddir=checkdir[1];			
		}else {memdir++;
		forwarddir=checkdir[2];	
		}
		checkdir[0]=forwarddir;  checkdir[1]=forwarddir.rotateLeft();  checkdir[2]=forwarddir.rotateRight();
		checkdir[3]=checkdir[1].rotateLeft();    checkdir[4]=checkdir[2].rotateRight();
	}
	
	
	public static boolean exploration() throws GameActionException {
		if(trypath.size()==0) {explore(); System.out.println("path found"+trypath.size());}
		
		
		if(rc.canMove(myloc.directionTo(trypath.get(0)))&& !rc.senseFlooding(trypath.get(0))) {
			try {
				rc.move(myloc.directionTo(trypath.get(0)));
				failnbr=0;
			} catch (GameActionException e) {
				e.printStackTrace();
			}
			squaredradius=rc.getCurrentSensorRadiusSquared();
			radius=racine[squaredradius];					
			myloc=rc.getLocation();
			if(trypath.size()==1) {
				visited.add(trypath.get(0));
			}
			trypath.remove(0);
			
		}else if(rc.isReady()) {
			failnbr++;
			if(failnbr>1) {
				changecheckdir();
				
			}
			visited.add(trypath.get(trypath.size()-1));
			trypath.clear();
			return false;
		}
		
		
		
		return true;
	}
	
	

}
