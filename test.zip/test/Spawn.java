package test;


import battlecode.common.*;


public class Spawn extends RobotPlayer {
	
public static Direction goodir() {
	Direction dir = Direction.NORTH;
	MapLocation me=rc.getLocation();
	MapLocation[] h= rc.senseNearbySoup();
	if(h.length!=0) {
		if(rc.canBuildRobot(RobotType.MINER,me.directionTo(h[0]))) {
		dir=me.directionTo(h[0]);
		return dir;}
	}
	
		for(Direction ds:Direction.allDirections()) {
			if(rc.canBuildRobot(RobotType.MINER,ds)) {
				System.out.println("buit "+ds);
				return ds;}
			
		}
	return dir;
}
}