package test;

import java.util.ArrayList;

import battlecode.common.*;

public class LandScaper2 extends Global {
	private static boolean needprotection=true;
	public static void landscaperidle() throws GameActionException {
		Nav.updateRobot(rc.senseNearbyRobots());
	//	System.out.println("myHQ "+myHQ);
		while(!rc.isReady()) {Clock.yield();}
		System.out.println("ready");
		while(true) {
			
		if((myHQ==null && opHQ==null) ||!needprotection ) {		
			System.out.println("explore");
			exploring();
		}
		if(opHQ!=null) {
			System.out.println("opHQ "+opHQ);
			Pathfind.going(opHQ);
			myloc=rc.getLocation();
			System.out.println("near ophq");
			destroyHQ(opHQ);
		}
		if(myHQ!=null && needprotection) {
			MapLocation vide=protection();
			if(!needprotection) {continue;}
			System.out.println("try1");
			if(Pathfind.going(myHQ)) {
				preparingwall();
				wallOfChina(myHQ);
				continue;
			}else {
				Pathfind.foundborder=!Pathfind.foundborder;
				if(Pathfind.going(myHQ)) {
					preparingwall();
					wallOfChina(myHQ);
					continue;
				}
			}
			System.out.println("fail1 try2 "+vide);
			Pathfind.going(vide);
			wallOfChina(vide);
		}

		//System.out.println("whila");
		}
		
	}
	public static void exploring() throws GameActionException {
		System.out.println("1");
		Nav.exploration();
		System.out.println("2");
		myloc=rc.getLocation();
		while(!rc.isReady()) {Clock.yield();}
		System.out.println("explored");
		Nav.updateRobot(rc.senseNearbyRobots());
		for(RobotInfo rb :rc.senseNearbyRobots()) {
			if(rb.getType().isBuilding()) {
				if(rb.getType()==RobotType.HQ) {
					System.out.println("ifound HQ");
					if(rb.getTeam()==rc.getTeam()) {
					protection();
				//	System.out.println("need "+needprotection);
					if(needprotection) {//System.out.println("HQ found need prot");
					return;
					}}
					}else {return;}
				if(rb.getTeam()==rc.getTeam() && rb.getDirtCarrying()!=0) {
					if(Pathfind.going(rb.getLocation())) {
						myloc=rc.getLocation();
						protect(rb);
						break;}
				}
				if(rb.getTeam()!=rc.getTeam()) {
					System.out.println("going to destroy ");
					if(Pathfind.going(rb.getLocation())) {
					myloc=rc.getLocation();
					System.out.println("pathfound");
					destroy(rb.getLocation());
					System.out.println("finished");

					break;}
				}
			}
		}
	}
	
	public static void wallOfChina(MapLocation target) throws GameActionException{
		
	
			myloc=rc.getLocation();
			MapLocation futur=myloc;
			while(!futur.isAdjacentTo(myHQ) &&needprotection) {
				futur=futur.add(futur.directionTo(target));
				if(rc.senseRobotAtLocation(futur)==null) {
					return;
				}
				if(futur.equals(target)) {
					break;
				}
				
				
			}
				while(!myloc.isAdjacentTo(myHQ) &&needprotection) {
					
					MapLocation forw=myloc.add(myloc.directionTo(target));
					while(!rc.isReady()) {Clock.yield();}
					fixElevation(forw);
					while(!rc.isReady()) {Clock.yield();}
					if(rc.canMove(myloc.directionTo(target))) {
						rc.move(myloc.directionTo(target));
						myloc=rc.getLocation();
					}else {System.out.println("faillure");while(!"e".equals("z")) {Clock.yield();}}
				}
				System.out.println("im adj to myHQ");
				while(true) {
					myloc=rc.getLocation();
				if(rc.senseRobotAtLocation(myHQ).getDirtCarrying()!=0) {
					protectHQ(rc.senseRobotAtLocation(myHQ));
				}
				for(RobotInfo enemy:rc.senseNearbyRobots(2,rc.getTeam().opponent())) {
					if(enemy.getType().isBuilding()) {
						MapLocation enmypos=enemy.getLocation();
						while(rc.senseRobotAtLocation(enmypos)!=null) {
							while(rc.canDepositDirt(rc.getLocation().directionTo(enmypos))) {
							tryDeposit(rc.getLocation().directionTo(enmypos));}
						
						tryDigDirt(Direction.CENTER);
						}
					}
				}
			tryDigDirt(myHQ.directionTo(rc.getLocation()));
			tryDeposit(Direction.CENTER);
			
				while(!rc.isReady()) {Clock.yield();}
				if(rc.getRoundNum()>250) {
				for(MapLocation ds:Nav.getSenseadjacent(myHQ)) {
					if(rc.senseRobotAtLocation(ds)==null) {
					tryDigDirt(myHQ.directionTo(rc.getLocation()));
					tryDeposit(rc.getLocation().directionTo(ds));
					}else if(rc.senseRobotAtLocation(ds).getTeam()==rc.getTeam().opponent() ||rc.senseRobotAtLocation(ds).getType()!=RobotType.LANDSCAPER) {
						tryDigDirt(myHQ.directionTo(rc.getLocation()));
						tryDeposit(rc.getLocation().directionTo(ds));
						}
				
				}
			}
				}
				
		}
	public static void destroy(MapLocation target) throws GameActionException{
		while(rc.senseRobotAtLocation(target)!=null) {
			while(rc.canDepositDirt(rc.getLocation().directionTo(target))) {
				tryDeposit(rc.getLocation().directionTo(target));}
		
		tryDigDirt(target.directionTo(rc.getLocation()));
		}	
	}
	public static void destroyHQ(MapLocation target) throws GameActionException{
		
		while(!myloc.isAdjacentTo(target)) {
			System.out.println("not adj "+target);
			MapLocation forw=myloc.add(myloc.directionTo(target));
			fixElevation(forw);
			if(rc.canMove(myloc.directionTo(target))) {
				rc.move(myloc.directionTo(target));
				myloc=rc.getLocation();
			}
		}
		while(rc.senseRobotAtLocation(target)!=null) {
			while(rc.canDepositDirt(rc.getLocation().directionTo(target))) {
				tryDeposit(rc.getLocation().directionTo(target));}
		
		tryDigDirt(Direction.CENTER);
		}	
	}
	public static void protectHQ(RobotInfo target) throws GameActionException{
		while(target.getDirtCarrying()!=0) {
			while(rc.canDigDirt(rc.getLocation().directionTo(target.getLocation()))) {
			tryDigDirt(rc.getLocation().directionTo(target.getLocation()));}
			tryDeposit(Direction.CENTER);
		}	
	}
	public static void protect(RobotInfo target) throws GameActionException{
		while(target.getDirtCarrying()!=0) {
			while(rc.canDigDirt(rc.getLocation().directionTo(target.getLocation()))) {
			tryDigDirt(rc.getLocation().directionTo(target.getLocation()));}
			tryDeposit(target.getLocation().directionTo(rc.getLocation()));
		}	
	}
		static boolean tryDigDirt(Direction dir) throws GameActionException {
			if(rc.canDigDirt(dir)) {
				rc.digDirt(dir);
				Clock.yield();
				return true;
				}
			else return false;
		}
		static boolean tryDeposit(Direction dir)throws GameActionException{
			if(rc.canDepositDirt(dir)) {
				rc.depositDirt(dir);
				Clock.yield();

				return true;
			}
			else return false;
		}
	
		static void fixElevation(MapLocation loc) throws GameActionException {

				while(rc.senseElevation(loc)+3<rc.senseElevation(rc.getLocation())) {
					tryDigDirt(Direction.CENTER);
					Clock.yield();
					tryDeposit(rc.getLocation().directionTo(loc));
					Clock.yield();
				}
				while(rc.senseElevation(loc)>rc.senseElevation(rc.getLocation())+3) {
					tryDigDirt(rc.getLocation().directionTo(loc));
					Clock.yield();
					tryDeposit(Direction.CENTER);
					Clock.yield();
				}
				
			
			
			
		}
		public static MapLocation protection() throws GameActionException {
			for(MapLocation base:Nav.getSenseadjacent(myHQ)) {
				if(rc.senseRobotAtLocation(base)==null) {
					needprotection=true;
					return base;
				}
			}
			needprotection=false;
			return null;
		}
		
		public static void preparingwall() throws GameActionException {
			MapLocation debut=rc.getLocation();
			Direction rot=myHQ.directionTo(debut).rotateRight().rotateRight();
			boolean revers=true;
			MapLocation next=debut.add(rot);
			if(!next.isAdjacentTo(myHQ)) {
				rot=rot.rotateRight();
				next=debut.add(rot);
			}
			System.out.println("next "+next);
			while(rc.senseRobotAtLocation(next)==null && !next.equals(debut)) {
				while(!rc.isReady()) {Clock.yield();}
				if(rc.canMove(rot)) {
					rc.move(rot);
					revers=false;
				}else {
					fixElevation(next);
					continue;
				}
				rot=myHQ.directionTo(rc.getLocation()).rotateRight().rotateRight();
				next=rc.getLocation().add(rot);
				if(!next.isAdjacentTo(myHQ)) {
					rot=rot.rotateRight();
					next=rc.getLocation().add(rot);
				}
			//	System.out.println("next "+next);

			}
		}
		
		
		
}
