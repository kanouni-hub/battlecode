package test;



import battlecode.common.*;

public class LandScaper2 extends Global {
	private static boolean needprotection=true;
	public static void landscaperidle() throws GameActionException {
		Message.HQLocation();
		
		Message.OpHQLocation();
		myloc=rc.getLocation();
		Message.builtwall();
		boolean attack=false;
		if(opHQ!=null) {
			if(myloc.distanceSquaredTo(opHQ)<myloc.distanceSquaredTo(myHQ)) {
				attack=true;
			}
		}
		while(!rc.isReady()) {Clock.yield();}
		System.out.println("ready");
		while(true) {
			Message.urgentmess();
			Message.builtwall();
			if(urgent==1) {pr=0;attack=false;}
	/*	if((myHQ==null && opHQ==null) ||!needprotection ) {		
			System.out.println("explore");
			exploring();
		} */
		//	System.out.println("pr "+pr);
		if(attack || pr==1) {
			if(opHQ!=null) {
			System.out.println("opHQ "+opHQ);
			Pathfind.going(opHQ);
			myloc=rc.getLocation();
			System.out.println("near ophq");
			destroyHQ(opHQ);}
			else {
				Symetrie.FindHQ(myHQ);
				if(opHQ!=null) {continue;}
				else {exploring();}
			}
			
		}
		else {
			MapLocation vide=protection();
		//	if(!needprotection) {continue;}
			System.out.println("try1");
			if(Pathfind.going(myHQ)) {
				preparingwall();
				wallOfChina(myHQ);
				continue;
			}else {
				Pathfind.foundborder=!Pathfind.foundborder;
				if(Pathfind.going(myHQ)) {
					preparingwall();
					wallOfChina(myHQ);
					continue;
				}
			}
			System.out.println("fail1 try2 "+vide);
			Pathfind.going(vide);
			wallOfChina(vide);
		}

		//System.out.println("whila");
		}
		
	}
	public static void exploring() throws GameActionException {
		System.out.println("1");
		Nav.exploration();
		System.out.println("2");
		myloc=rc.getLocation();
		while(!rc.isReady()) {Clock.yield();}
		System.out.println("explored");
		Nav.updateRobot(rc.senseNearbyRobots());
		for(RobotInfo rb :rc.senseNearbyRobots()) {
			if(rb.getType().isBuilding()) {
				if(rb.getType()==RobotType.HQ) {
					System.out.println("ifound HQ");
					if(rb.getTeam()==rc.getTeam()) {
					protection();
				//	System.out.println("need "+needprotection);
					if(needprotection) {//System.out.println("HQ found need prot");
					return;
					}}
					}else {return;}
				if(rb.getTeam()==rc.getTeam() && rb.getDirtCarrying()!=0) {
					if(Pathfind.going(rb.getLocation())) {
						myloc=rc.getLocation();
						protect(rb);
						break;}
				}
				if(rb.getTeam()!=rc.getTeam()) {
					System.out.println("going to destroy ");
					if(Pathfind.going(rb.getLocation())) {
					myloc=rc.getLocation();
					System.out.println("pathfound");
					destroy(rb.getLocation());
					System.out.println("finished");

					break;}
				}
			}
		}
	}
	
	public static void wallOfChina(MapLocation target) throws GameActionException{
			int roundstart=rc.getRoundNum();
	boolean candig=false;
	int waiting=0;
			myloc=rc.getLocation();
			MapLocation futur=myloc;
			while(!futur.isAdjacentTo(myHQ) &&needprotection) {
				futur=futur.add(futur.directionTo(target));
				if(rc.senseRobotAtLocation(futur)==null) {
					return;
				}
				if(futur.equals(target)) {
					break;
				}
				
				
			}
				while(!myloc.isAdjacentTo(myHQ) &&needprotection) {
					
					MapLocation forw=myloc.add(myloc.directionTo(target));
					while(!rc.isReady()) {Clock.yield();}
					fixElevation(forw);
					while(!rc.isReady()) {Clock.yield();}
					if(rc.canMove(myloc.directionTo(target))) {
						rc.move(myloc.directionTo(target));
						myloc=rc.getLocation();
					}else {return;}
				}
				System.out.println("im adj to myHQ");
				myloc=rc.getLocation();
				while(true) {
					while(!rc.isReady()) {Clock.yield();}
					
				if(rc.senseRobotAtLocation(myHQ).getDirtCarrying()!=0) {
					protectHQ(rc.senseRobotAtLocation(myHQ));
				}
				for(RobotInfo enemy:rc.senseNearbyRobots(2,rc.getTeam().opponent())) {
					if(enemy.getType().isBuilding()) {
						MapLocation enmypos=enemy.getLocation();
						while(rc.senseRobotAtLocation(enmypos)!=null) {
							while(rc.canDepositDirt(rc.getLocation().directionTo(enmypos))) {
							tryDeposit(rc.getLocation().directionTo(enmypos));}
						
						tryDigDirt(Direction.CENTER);
						}
					}
				}
			for(MapLocation dig :Nav.getSenseadjacent(rc.getLocation())) {
				if(!dig.isAdjacentTo(myHQ)) {
					if(rc.senseRobotAtLocation(dig)!=null) {
						if(rc.senseRobotAtLocation(dig).getTeam()==rc.getTeam() &&rc.senseRobotAtLocation(dig).getType()!=RobotType.DELIVERY_DRONE) {
							continue;
						}
					}
					if(tryDigDirt(rc.getLocation().directionTo(dig))) {
						candig=true;
						break;
					}
				}
			}
			tryDeposit(Direction.CENTER);
			if(!candig) {
				for(MapLocation dig :Nav.getSenseadjacent(myHQ)) {
					while(!rc.isReady()) {Clock.yield();}
					tryDigDirt(Direction.CENTER);
					tryDeposit(rc.getLocation().directionTo(dig));
						
				}
			}
			
				while(!rc.isReady()) {Clock.yield();}
				if(rc.getRoundNum()>roundstart+240) {
				for(MapLocation ds:Nav.getSenseadjacent(myHQ)) {
					if(ds.isAdjacentTo(rc.getLocation())) {
						if(rc.onTheMap(ds.add(rc.getLocation().directionTo(ds))) && rc.onTheMap(ds.add(myHQ.directionTo(ds)))) {
							if(rc.senseElevation(ds)<rc.senseElevation(rc.getLocation())) {
								for(MapLocation dig :Nav.getSenseadjacent(rc.getLocation())) {
									if(!dig.isAdjacentTo(myHQ)) {
										if(tryDigDirt(rc.getLocation().directionTo(dig))) {
											break;
										}
									}
								}
								tryDeposit(rc.getLocation().directionTo(ds));
								
							}
						}
					}
					
				
				}
			}
				}
				
		}
	public static void destroy(MapLocation target) throws GameActionException{
		while(rc.senseRobotAtLocation(target)!=null) {
			while(rc.canDepositDirt(rc.getLocation().directionTo(target))) {
				tryDeposit(rc.getLocation().directionTo(target));}
		
		tryDigDirt(target.directionTo(rc.getLocation()));
		}	
	}
	public static void destroyHQ(MapLocation target) throws GameActionException{
		myloc=rc.getLocation();
		while(!myloc.isAdjacentTo(target)) {
			System.out.println("not adj "+target);
			MapLocation forw=myloc.add(myloc.directionTo(target));
			fixElevation(forw);
			if(rc.canMove(myloc.directionTo(target))) {
				rc.move(myloc.directionTo(target));
				myloc=rc.getLocation();
			}
		}
		while(rc.senseRobotAtLocation(target)!=null) {
			while(rc.canDepositDirt(rc.getLocation().directionTo(target))) {
				tryDeposit(rc.getLocation().directionTo(target));}
		
		tryDigDirt(Direction.CENTER);
		}	
	}
	public static void protectHQ(RobotInfo target) throws GameActionException{
		while(target.getDirtCarrying()!=0) {
			while(rc.canDigDirt(rc.getLocation().directionTo(target.getLocation()))) {
			tryDigDirt(rc.getLocation().directionTo(target.getLocation()));}
			tryDeposit(Direction.CENTER);
		}	
	}
	public static void protect(RobotInfo target) throws GameActionException{
		while(target.getDirtCarrying()!=0) {
			while(rc.canDigDirt(rc.getLocation().directionTo(target.getLocation()))) {
			tryDigDirt(rc.getLocation().directionTo(target.getLocation()));}
			tryDeposit(target.getLocation().directionTo(rc.getLocation()));
		}	
	}
		static boolean tryDigDirt(Direction dir) throws GameActionException {
			if(rc.canDigDirt(dir)) {
				rc.digDirt(dir);
				Clock.yield();
				return true;
				}
			else return false;
		}
		static boolean tryDeposit(Direction dir)throws GameActionException{
			if(rc.canDepositDirt(dir)) {
				rc.depositDirt(dir);
				Clock.yield();

				return true;
			}
			else return false;
		}
	
		static void fixElevation(MapLocation loc) throws GameActionException {

				while(rc.senseElevation(loc)+3<rc.senseElevation(rc.getLocation())) {
					tryDigDirt(Direction.CENTER);
					Clock.yield();
					tryDeposit(rc.getLocation().directionTo(loc));
					Clock.yield();
				}
				while(rc.senseElevation(loc)>rc.senseElevation(rc.getLocation())+3) {
					tryDigDirt(rc.getLocation().directionTo(loc));
					Clock.yield();
					tryDeposit(Direction.CENTER);
					Clock.yield();
				}
				
			
			
			
		}
		public static MapLocation protection() throws GameActionException {
			for(MapLocation base:Nav.getSenseadjacent(myHQ)) {
				if(rc.senseRobotAtLocation(base)==null) {
					needprotection=true;
					return base;
				}
			}
			needprotection=false;
			return null;
		}
		
		public static void preparingwall() throws GameActionException {
			MapLocation debut=rc.getLocation();
			Direction rot=myHQ.directionTo(debut).rotateRight().rotateRight();
			boolean revers=true;
			MapLocation next=debut.add(rot);
			if(!next.isAdjacentTo(myHQ)) {
				rot=rot.rotateRight();
				next=debut.add(rot);
			}
			System.out.println("next "+next);
			while(!next.equals(debut) && rc.onTheMap(next)) {
				System.out.println("next "+next);
				if(rc.senseRobotAtLocation(next)==null) {
				while(!rc.isReady()) {Clock.yield();}
				if(rc.canMove(rot)) {
					rc.move(rot);
					revers=false;
				}else {
					fixElevation(next);
					continue;
				}
				rot=myHQ.directionTo(rc.getLocation()).rotateRight().rotateRight();
				next=rc.getLocation().add(rot);
				if(!next.isAdjacentTo(myHQ)) {
					rot=rot.rotateRight();
					next=rc.getLocation().add(rot);
				}

			}else{break;
				}
			}
		}
		
		
		
}
