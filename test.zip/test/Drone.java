package test;
import battlecode.common.*;
public class Drone extends Symetrie {
	static MapLocation floodcase=null;
	public static void droneassault() throws GameActionException {
		opHQ=new MapLocation(10,10);
		if (opHQ != null) {
			int r = 4;
			MapLocation[] H = { new MapLocation(opHQ.x-r,opHQ.y), new MapLocation(opHQ.x-r,opHQ.y+1),new MapLocation(opHQ.x-r,opHQ.y+2),new MapLocation(opHQ.x-r+1,opHQ.y+3),new MapLocation(opHQ.x-r+2,opHQ.y+4),new MapLocation(opHQ.x-r+3,opHQ.y+4),new MapLocation(opHQ.x-r+4,opHQ.y+4),new MapLocation(opHQ.x-r+5,opHQ.y+4),new MapLocation(opHQ.x-r+6,opHQ.y+4),new MapLocation(opHQ.x-r+7,opHQ.y+3),new MapLocation(opHQ.x-r+8,opHQ.y+2),new MapLocation(opHQ.x-r+8,opHQ.y+1),new MapLocation(opHQ.x-r+8,opHQ.y),new MapLocation(opHQ.x-r+8,opHQ.y-1),new MapLocation(opHQ.x-r+8,opHQ.y-2),new MapLocation(opHQ.x-r+5,opHQ.y-2),new MapLocation(opHQ.x-r+7,opHQ.y-3),new MapLocation(opHQ.x-r+6,opHQ.y-4),new MapLocation(opHQ.x-r+5,opHQ.y-4),new MapLocation(opHQ.x-r+4,opHQ.y-4),new MapLocation(opHQ.x-r+3,opHQ.y-4),new MapLocation(opHQ.x-r+2,opHQ.y-4),new MapLocation(opHQ.x-r+1,opHQ.y-3),new MapLocation(opHQ.x-r,opHQ.y-2),new MapLocation(opHQ.x-r,opHQ.y-1)};					
				if(Pathfind.doneHQ(opHQ)) {						
							}
			System.out.println("done");
			while(r==4) {Clock.yield();}
			
		}
		else {
			Nav.updateRobot(rc.senseNearbyRobots());
			myHQ=new MapLocation(37,37);
			FindHQ(myHQ);
			droneassault();
		}
			
	}

	

}