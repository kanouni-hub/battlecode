package test;
import battlecode.common.*;
public class Drone extends Symetrie {
	static MapLocation floodcase=null;
	public static void droneassault() throws GameActionException {
		opHQ=new MapLocation(10,10);
		if (opHQ != null) {
			int r = 4;
			MapLocation[] H = { new MapLocation(opHQ.x-r,opHQ.y), new MapLocation(opHQ.x-r,opHQ.y+1),new MapLocation(opHQ.x-r,opHQ.y+2),new MapLocation(opHQ.x-r+1,opHQ.y+3),new MapLocation(opHQ.x-r+2,opHQ.y+4),new MapLocation(opHQ.x-r+3,opHQ.y+4),new MapLocation(opHQ.x-r+4,opHQ.y+4),new MapLocation(opHQ.x-r+5,opHQ.y+4),new MapLocation(opHQ.x-r+6,opHQ.y+4),new MapLocation(opHQ.x-r+7,opHQ.y+3),new MapLocation(opHQ.x-r+8,opHQ.y+2),new MapLocation(opHQ.x-r+8,opHQ.y+1),new MapLocation(opHQ.x-r+8,opHQ.y),new MapLocation(opHQ.x-r+8,opHQ.y-1),new MapLocation(opHQ.x-r+8,opHQ.y-2),new MapLocation(opHQ.x-r+5,opHQ.y-2),new MapLocation(opHQ.x-r+7,opHQ.y-3),new MapLocation(opHQ.x-r+6,opHQ.y-4),new MapLocation(opHQ.x-r+5,opHQ.y-4),new MapLocation(opHQ.x-r+4,opHQ.y-4),new MapLocation(opHQ.x-r+3,opHQ.y-4),new MapLocation(opHQ.x-r+2,opHQ.y-4),new MapLocation(opHQ.x-r+1,opHQ.y-3),new MapLocation(opHQ.x-r,opHQ.y-2),new MapLocation(opHQ.x-r,opHQ.y-1)};					
				if(Pathfind.doneHQ(opHQ)) {						
							}
			System.out.println("done");
			while(r==4) {Clock.yield();}
			
		}
		else {
			Nav.updateRobot(rc.senseNearbyRobots());
			myHQ=new MapLocation(37,37);
			FindHQ(myHQ);
			droneassault();
		}
			
	}

	public static MapLocation Closetflood=null;
	public static void protectHQ() throws GameActionException {
		Message.HQLocation();
		while(rc.getLocation().distanceSquaredTo(myHQ)>8) {
			 Direction forwarddir=rc.getLocation().directionTo(myHQ);
				Direction[] checkdir=new Direction[] {forwarddir,forwarddir.rotateLeft(),forwarddir.rotateRight(),forwarddir.rotateLeft().rotateLeft(),forwarddir.rotateRight().rotateRight()};;
			while(!rc.isReady()) {Clock.yield();}
				for(Direction got:checkdir) {
					if(rc.canMove(got)) {
						rc.move(got);
						
						break;
					}}
		}
	
	RobotInfo[] enemyrobot=rc.senseNearbyRobots(rc.getCurrentSensorRadiusSquared(),rc.getTeam().opponent());
	for(RobotInfo rb:enemyrobot) {
		if(rb.getType()==RobotType.LANDSCAPER || rb.getType()==RobotType.MINER) {
			System.out.println("killig "+rb.getID());
			kill(rb.getID());
			break;
		}
	}
	RobotInfo[] hqadj=rc.senseNearbyRobots(myHQ,3,rc.getTeam());
	System.out.println("walling");
	for(RobotInfo rb:hqadj) {
		if(rb.getType()==RobotType.MINER) {
			pickvisibleUnit(rb.getID());
			System.out.println("picked");
			while(!rc.isReady()) {Clock.yield();}
			if(rc.isCurrentlyHoldingUnit()) {
				Pathfind.going(myHQ.translate(3,2));
				myloc=rc.getLocation();
				while(!rc.isReady()) {Clock.yield();}
				for(Direction dq:Direction.allDirections()) {
					if(rc.canDropUnit(dq)) {
						if(!rc.senseFlooding(myloc.add(dq))) {
						rc.dropUnit(dq);
						break;}
					}
				}
			}
			break;
		}
	}
	protectHQ();
	}
	public static boolean issafemove(Direction dir) throws GameActionException {
		while(!rc.isReady()) {Clock.yield();}
		if(!rc.canMove(dir)) {
			return false;
		}
		RobotInfo[] enemyrobot=rc.senseNearbyRobots(rc.getCurrentSensorRadiusSquared(),rc.getTeam().opponent());
		for(RobotInfo ri:enemyrobot) {
			if((ri.getType()==RobotType.NET_GUN || ri.getType()==RobotType.HQ) && rc.getLocation().distanceSquaredTo(ri.getLocation())<15) {
				return false;
			}
		}
		rc.move(dir);
		return true;
	}
	public static void findwater() throws GameActionException {
		Message.HQLocation();
		if(Closetflood==null) {
			MapLocation[] Possible = {verticale(myHQ), horizantal(verticale(myHQ)),horizantal(myHQ),Diagonale(myHQ)};
			for(MapLocation uh :Possible) {
				System.out.println("twatr "+uh);
				Pathfind.dronewater(uh);
				myloc=rc.getLocation();
				System.out.println("endwater "+myloc);
				for(MapLocation adj:Nav.getSenseadjacent(myloc)) {
					if(rc.senseFlooding(adj)) {
						System.out.println("water found "+adj);
						Closetflood=adj;
						return;
					}
				}
				
			}
		}else {Pathfind.dronewater(Closetflood);}
	}
	public static void kill(int id) throws GameActionException {
		if(!rc.isCurrentlyHoldingUnit()) {
			pickvisibleUnit(id);	
		}
		if(rc.isCurrentlyHoldingUnit()) {
			findwater();
			myloc=rc.getLocation();
			while(!rc.isReady()) {Clock.yield();}
			if(Closetflood!=null) {
				if(rc.canDropUnit(myloc.directionTo(Closetflood))) {
					rc.dropUnit(myloc.directionTo(Closetflood));
				}
			}
		}
	}
	public static void pickvisibleUnit(int id) throws GameActionException {
		while(rc.canSenseRobot(id) && !rc.isCurrentlyHoldingUnit()) {
		if(!rc.isReady()) {Clock.yield();}
		if(rc.canSenseRobot(id) && !rc.isCurrentlyHoldingUnit()) {
			if(rc.canPickUpUnit(id)) {
				rc.pickUpUnit(id);
			}else {
				 Direction forwarddir=rc.getLocation().directionTo(rc.senseRobot(id).getLocation());
				Direction[] checkdir=new Direction[] {forwarddir,forwarddir.rotateLeft(),forwarddir.rotateRight(),forwarddir.rotateLeft().rotateLeft(),forwarddir.rotateRight().rotateRight()};;
				for(Direction got:checkdir) {
					if(rc.canMove(got)) {
						rc.move(got);
						break;
					}
				}
			}
		}
		}
	}
	public static void droneturn() throws GameActionException {
		while(true) {
		Message.HQLocation();
		myloc=rc.getLocation();
		while(rc.getLocation().distanceSquaredTo(myHQ)>8) {
			 Direction forwarddir=rc.getLocation().directionTo(myHQ);
				Direction[] checkdir=new Direction[] {forwarddir,forwarddir.rotateLeft(),forwarddir.rotateRight(),forwarddir.rotateLeft().rotateLeft(),forwarddir.rotateRight().rotateRight()};;
			while(!rc.isReady()) {Clock.yield();}
				for(Direction got:checkdir) {
					if(rc.canMove(got)) {
						rc.move(got);
						
						break;
					}}
		}
		preparwall();
		RobotInfo[] enemyrobot=rc.senseNearbyRobots(rc.getCurrentSensorRadiusSquared(),rc.getTeam().opponent());
		for(RobotInfo rb:enemyrobot) {
			if(rb.getType()==RobotType.LANDSCAPER || rb.getType()==RobotType.MINER) {
				System.out.println("killig "+rb.getID());
				kill(rb.getID());
				break;
			}
		}
		}
		
	}
	public static void preparwall() throws GameActionException {
		MapLocation design=new MapLocation(48,55);
		Message.HQLocation();
		myloc=rc.getLocation();
		if(myloc.isAdjacentTo(myHQ)) {
			for(Direction ds:Direction.allDirections()) {
				if(rc.canMove(ds)) {
					rc.move(ds);
					break;}
				
			}
		}
		for(MapLocation mp:Nav.getSenseadjacent(myHQ)) {
			if(rc.senseRobotAtLocation(mp)==null) {
				Pathfind.going(design);
				boolean landscaper=false;
				while(!landscaper) {
					RobotInfo[] lnd=rc.senseNearbyRobots(rc.getCurrentSensorRadiusSquared(),rc.getTeam());
					for(RobotInfo rf:lnd) {
						if(rf.getType()==RobotType.LANDSCAPER && !rf.getLocation().isAdjacentTo(myHQ)) {
							landscaper=true;
							pickvisibleUnit(rf.getID());
							break;
						}
					}
				}
				Pathfind.going(mp);
				myloc=rc.getLocation();
				
				while(!rc.isReady()) {Clock.yield();}
				if(rc.canDropUnit(myloc.directionTo(mp))) {
					rc.dropUnit(myloc.directionTo(mp));
					return;
				}else {
					for(Direction ds:Direction.allDirections()) {
						if(rc.canDropUnit(ds)) {
							rc.dropUnit(ds);
							return;}
						
					}
				}
			}
			else if(rc.senseRobotAtLocation(mp).getType()==RobotType.MINER) {
				pickvisibleUnit(rc.senseRobotAtLocation(mp).getID());
				System.out.println("picked");
				while(!rc.isReady()) {Clock.yield();}
				if(rc.isCurrentlyHoldingUnit()) {
					Pathfind.going(myHQ.translate(3,2));
					myloc=rc.getLocation();
					while(!rc.isReady()) {Clock.yield();}
					for(Direction dq:Direction.allDirections()) {
						if(rc.canDropUnit(dq)) {
							if(!rc.senseFlooding(myloc.add(dq))) {
							rc.dropUnit(dq);
							return;}
						}
					}
				
			}
		}
			}
	
	}

}